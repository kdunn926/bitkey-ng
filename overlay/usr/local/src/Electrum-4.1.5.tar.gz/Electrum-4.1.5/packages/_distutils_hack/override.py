__import__('_distutils_hack').do_override()
